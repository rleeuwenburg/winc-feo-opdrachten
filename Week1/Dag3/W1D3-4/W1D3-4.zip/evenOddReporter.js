for (let number = 0; number <= 20; number++) {
  if (number % 2 === 0) {
    console.log(number + ' is even');
  } else {
    console.log(number + ' is oneven');
  }
}

// for (let i = 1; i <= 10; i++) {
//   let multiplier = 9;
//   let result = i * multiplier;
//   console.log(i + ' * ' + multiplier + ' = ' + result);
// }

for (let i = 1; i <= 10; i++) {
  for (let multiplier = 1; multiplier <= 10; multiplier++) {
    let result = i * multiplier;
    console.log(i + ' * ' + multiplier + ' = ' + result);
  }
}

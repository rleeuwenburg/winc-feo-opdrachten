const tellFortune = function(children, partner, location, job) {
  console.log(
    'You will be a ' +
      job +
      ' in ' +
      location +
      ' ,and married to ' +
      partner +
      ' with ' +
      children +
      'kids.'
  );
};

tellFortune('1', 'Francisca', 'Pernis', 'FED');
